import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}"
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: { "2xl": "1400px" }
    },
    extend: {
      fontFamily: {
        sans: ["DM Sans", "system-ui", "sans-serif"],
        display: ["Syne", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Fira Code", "monospace"],
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        brand: {
          navy: "#26316a",
          purple: "#7c3aed",
          blue: "#6366f1",
          violet: "#8b5cf6"
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))"
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))"
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))"
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))"
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))"
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))"
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))"
        },
        success: {
          DEFAULT: "hsl(var(--success))",
          foreground: "hsl(var(--success-foreground))"
        },
        warning: {
          DEFAULT: "hsl(var(--warning))",
          foreground: "hsl(var(--warning-foreground))"
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
          muted: "hsl(var(--sidebar-muted))",
        },
      },
      borderRadius: {
        sm: "calc(var(--radius) - 6px)",
        md: "calc(var(--radius) - 3px)",
        lg: "var(--radius)",
        xl: "calc(var(--radius) + 4px)",
        "2xl": "calc(var(--radius) + 10px)",
        "3xl": "calc(var(--radius) + 18px)",
      },
      boxShadow: {
        "brand-sm": "0 2px 12px -2px rgba(109,40,217,0.18)",
        "brand-md": "0 8px 32px -4px rgba(109,40,217,0.28), 0 0 0 1px rgba(139,92,246,0.12)",
        "brand-lg": "0 16px 56px -8px rgba(109,40,217,0.35), 0 0 0 1px rgba(139,92,246,0.18)",
        "glow-v": "0 0 28px rgba(139,92,246,0.45)",
        "glow-i": "0 0 28px rgba(99,102,241,0.45)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" }
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" }
        },
        "slide-up": {
          from: { opacity: "0", transform: "translateY(12px)" },
          to: { opacity: "1", transform: "translateY(0)" }
        },
        "slide-right": {
          from: { opacity: "0", transform: "translateX(-10px)" },
          to: { opacity: "1", transform: "translateX(0)" }
        },
        "scale-in": {
          from: { opacity: "0", transform: "scale(0.94)" },
          to: { opacity: "1", transform: "scale(1)" }
        },
        "fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" }
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "slide-up": "slide-up 0.32s cubic-bezier(0.22,1,0.36,1)",
        "slide-right": "slide-right 0.28s cubic-bezier(0.22,1,0.36,1)",
        "scale-in": "scale-in 0.22s cubic-bezier(0.22,1,0.36,1)",
        "fade-in": "fade-in 0.25s ease",
      },
    },
  },

  plugins: [
    require("tailwindcss-animate"),

    // 🔥 CUSTOM SCROLLBAR
    function ({ addUtilities }) {
      addUtilities({
        /* ❌ ESCONDE SCROLL VERTICAL */
        ".scrollbar-y-hidden::-webkit-scrollbar:vertical": {
          display: "none",
        },

        ".scrollbar-y-hidden": {
          "-ms-overflow-style": "none",
          "scrollbar-width": "none",
        },

        /* 🎨 SCROLL HORIZONTAL ESCURO */
        ".scrollbar-x-dark::-webkit-scrollbar:horizontal": {
          height: "6px",
        },

        ".scrollbar-x-dark::-webkit-scrollbar-thumb:horizontal": {
          backgroundColor: "#1f2937",
          borderRadius: "9999px",
          border: "2px solid transparent",
          backgroundClip: "content-box",
        },

        ".scrollbar-x-dark::-webkit-scrollbar-track:horizontal": {
          backgroundColor: "transparent",
        },
      });
    },
  ],
} satisfies Config;